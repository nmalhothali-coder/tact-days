# TACT DAYS — Seed Data

Initial database content for the TACT DAYS platform, derived from Tact's curated 2027 content calendar.

```
categories.csv      14 rows    import FIRST (occasions reference it by slug)
occasions.csv      124 rows    the dataset
review-queue.csv    89 rows    what the editorial team needs to resolve
```

Files are UTF-8 with BOM so Excel opens the Arabic correctly. Postgres and Supabase both read them fine.

---

## Import order

1. `categories.csv` → `categories`
2. `occasions.csv` → `occasions`, resolving `category_slug` to `category_id`

```sql
-- after loading occasions.csv into a staging table
insert into occasions (slug, name_en, name_ar, month, day, calendar_type, hijri_month, hijri_day,
                       recurrence, recurrence_rule, category_id, official_source, source_org,
                       verification_status, marketing_relevance, sensitivity, scope, countries, notes)
select s.slug, s.name_en, s.name_ar, s.month, s.day, s.calendar_type,
       nullif(s.hijri_month,'')::smallint, nullif(s.hijri_day,'')::smallint,
       s.recurrence, nullif(s.recurrence_rule,''), c.id,
       nullif(s.official_source,''), nullif(s.source_org,''),
       s.verification_status, s.marketing_relevance::smallint, s.sensitivity, s.scope,
       case when s.countries = '' then null else string_to_array(s.countries, ',') end,
       nullif(s.notes,'')
from staging_occasions s
join categories c on c.slug = s.category_slug;
```

`import_flag` is not a database column — it is the reason each row appears in the review queue. Keep it with the CSV, or load it into `notes` if you want it visible in the admin.

---

## Two schema additions beyond the master prompt

**`sensitivity`** — `standard` | `sensitive`. 18 occasions are marked sensitive: cancer, autism, Down syndrome, MS, AIDS, mental health, suicide-adjacent, humanitarian, violence against women, drug abuse, Alzheimer's. The AI route reads this field and switches to awareness-and-contribution mode, refusing promotional angles. Without a column the guardrail is guesswork on every request.

**`recurrence` is enforced, not decorative** — it is what keeps the ICS export honest:

| value | count | ICS behaviour |
|---|---|---|
| `annual_fixed` | 106 | `RRULE:FREQ=YEARLY` |
| `annual_lunar` | 9 | **no RRULE** — compute Gregorian dates per year from `hijri_month`/`hijri_day` |
| `annual_variable` | 7 | **no RRULE** — resolve from `recurrence_rule`, emit explicit VEVENTs |
| `month_long` | 3 | event spanning the whole month, or a banner rather than a calendar entry |

The 7 variable ones: Earth Hour (last Saturday of March), Black Friday (fourth Friday of November), Riyadh Marathon, Saudi Media Forum, LEAP, Hajj Conference, Cityscape Global.

---

## What I changed during conversion, and why

Nothing was changed silently. Every edited row carries an `import_flag`, and all 89 flagged rows are listed in `review-queue.csv`.

**Names filled or corrected (8).** Six rows had an empty `name_en`; two of those had the English name sitting in the Arabic column (LEAP, Cityscape Global) so both fields were set correctly. "Araffa day" → "Day of Arafah". "nternational Day for the Elimination of Violence Against Women" → leading letter restored. Two royal-allegiance entries had garbled or truncated English.

**Scope corrected on 7 rows.** The source marked Saudi National Day, Kuwait National Day, LEAP, Hajj Conference, Cityscape Global, the Crown Prince allegiance anniversary, and Tact's own anniversary as `global`. They are country- or company-specific. Final split: 99 global, 25 local.

**One occasion recovered.** World Alzheimer's Month existed only as a month-level note in the source file, not as an occasion row. It was added — hence 124 rows, not 123.

**Mother's Day stays duplicated** (21 March and 10 May). Both are legitimate in different regions; the slugs are disambiguated and `countries` should be set during review.

---

## What the editorial team still owns

- **66 rows cite a secondary source** (nationaltoday, timeanddate, observances.global, Wikipedia). Fine as a starting point, not as the official reference. Replace with the primary organisation's page before marking verified. Only 14 rows currently cite un.org, 3 cite WHO, 11 cite Saudi government sources.
- **14 rows have no source at all** — mostly the Hijri occasions and Saudi events.
- **All descriptions and significance fields are empty.** Deliberately. These are the editorial layer that makes the platform worth visiting, and inventing them would violate the first ground rule. Write them, or draft them with AI and have a human verify.
- **All images are empty.** The branded fallback should carry the platform until licensed artwork exists.
- **Everything is `unverified`** and therefore invisible to the public until an editor approves it.

---

## Two category problems worth deciding on

**`international-global` has zero occasions.** It overlaps every other category — almost everything here is an international day. Either delete it, or redefine it as "UN-designated days" and auto-populate it from `source_org = 'UN'` (14 rows today).

**`awareness-campaigns` has two.** Breast Cancer Month and Alzheimer's Month. The 18 `sensitivity = sensitive` rows are scattered across health, social, and seasonal. Consider making awareness a cross-cutting tag rather than a category, so an occasion can be both "Health" and "Awareness".

Relevance scores (1–5) are my editorial first pass, used to pick the featured occasion when several fall on one date. 22 rows scored 5, 42 scored 4. Treat them as a starting point, not a verdict.
